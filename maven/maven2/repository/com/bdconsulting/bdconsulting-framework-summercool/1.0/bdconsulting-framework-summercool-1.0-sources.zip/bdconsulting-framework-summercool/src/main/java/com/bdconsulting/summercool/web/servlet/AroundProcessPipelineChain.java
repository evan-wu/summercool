package com.bdconsulting.summercool.web.servlet;

/**
 * 
 * @author:shaochuan.wangsc
 * @date:2010-3-10
 *
 */
public class AroundProcessPipelineChain {

}
